@extends('layouts.frontend')
@section('content')
    <section class="listing-detail-page">
        <div class="container">
            <div class="row mb-5">
                <div class="col-lg-9 col-12">
                    <div class="swiper listing-swiper" style="height: 500px">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <img src="{{ assets('images/sale1.jpg') }}" alt="" srcset="">
                            </div>
                            <div class="swiper-slide">
                                <img src="{{ assets('images/sale2.jpg') }}" alt="" srcset="">
                            </div>
                        </div>
                        <div id="listing-swiper-next" class="swiper-button-next text-red"></div>
                        <div id="listing-swiper-prev" class="swiper-button-prev text-red"></div>
                        <div id="listing-swiper-pagination" class="swiper-pagination"></div>
                    </div>
                    <h1>
                        Coffee Shop with authentic interior at Jumeirah, Dubai
                    </h1>
                    <div class="description">
                        <p>
                            Our team members are Registered Business Valuers, which means we are qualified to perform a
                            formal
                            valuation of your existing or prospective business.

                            We apply a robust methodology to every business we value and have access to an up-to-date
                            database
                            of businesses sold by industry and location. We also perform various types of valuations to meet
                            your needs and budget, such as:
                        <ul>
                            <li>
                                <p>Complete business valuations </p>
                            </li>
                            <li>
                                <p>Market appraisals </p>
                            </li>
                            <li>
                                <p>Limited Valuations </p>
                            </li>
                        </ul>
                        </p>
                    </div>
                </div>
                <div class="col-3">
                    <div class="listing-detail-right">
                        <span class="status-before"></span>
                        <span class="status bg-black">Under Loi</span>
                        <div class="row">
                            <div class="col-5 title">Category</div>
                            <div class="col-7 value">Automotive</div>

                            <div class="col-5 title">City</div>
                            <div class="col-7 value">Dubai</div>

                            <div class="col-5 title">Price</div>
                            <div class="col-7 value">20,000,000 AED</div>

                            <div class="col-5 title">Reference ID</div>
                            <div class="col-7 value">0001</div>
                        </div>
                    </div>
                    <div class="col-12 get-in-touch box-shadow mt-4">
                        <span class="h1 line">Get in touch</span> <br>
                        <span class="sub-heading">to know more about this property</span>

                        <form action="">
                            <div class="form-group">
                                <label for="">Name</label>
                                <input type="text" name="name" id="name" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="">phone</label>
                                <input type="text" name="phone" id="phone" class="form-control">
                            </div>

                            <div class="form-group">
                                <label for="">email</label>
                                <input type="text" name="email" id="email" class="form-control">
                            </div>

                            <div class="form-group">
                                <label class="form-label" for="">Message</label>
                                <textarea type="text" name="messagetext" class="form-control"></textarea>
                            </div>

                            <div class="form-group text-right">
                                <button class="btn btn-red col-5">send</button>
                            </div>

                        </form>
                    </div>
                    <div class="col-12 listing-share box-shadow mt-4">
                        <span class="h1 line">Get in touch</span> <br>
                        <span class="sub-heading">You can share this listing through</span>
                        <div class="row">
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>
                            <div class="col-2">
                                <a href="">
                                    <img src="{{ assets('images/video-icon.png') }}" alt="">
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </div>
    </section>
@endsection

@section('js')
    <script>
        var listingSwiper = new Swiper(".listing-swiper", {
            pagination: {
                el: "#listing-swiper-pagination",
                clickable: true
            },
            navigation: {
                nextEl: "#listing-swiper-next",
                prevEl: "#listing-swiper-prev",
            },
        });
    </script>
@endsection
