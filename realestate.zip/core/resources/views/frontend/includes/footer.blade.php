<footer class="pt-5 footer" style="background:url('{{ assets('images/footer.jpg') }}')">
    <div class="container">
        <div class="row b-b">
            <div class="col-lg-4 col-12">
                <ul>
                    <li>
                        <h3>Quick links</h3>
                    </li>
                    <li>
                        <a href="#">About Us</a>
                    </li>
                    <li>
                        <a href="#">Our Services</a>
                    </li>
                    <li>
                        <a href="#">Our Team</a>
                    </li>
                    <li>
                        <a href="#">Our Partners</a>
                    </li>
                    <li>
                        <a href="#">Become a Business Broker</a>
                    </li>
                    <li>
                        <a href="#">Work With Us</a>
                    </li>
                    <li>
                        <a href="#">Blog</a>
                    </li>
                    <li>
                        <a href="#">Testimonials</a>
                    </li>
                    <li>
                        <a href="#">Off-Market Projects</a>
                    </li>
                    <li>
                        <a href="#">Sign Up To Our Newsletter</a>
                    </li>
                </ul>
            </div>

            <div class="col-lg-4 col-12">
                <ul>
                    <li>
                        <h3>Register as a Buyer</h3>
                    </li>
                    <li>
                        <a href="#">View All Businesses for Sale</a>
                    </li>
                    <li>
                        <a href="#">Confidential Off-Market Projects</a>
                    </li>
                    <li>
                        <a href="#">Register as a Buyer</a>
                    </li>
                    <li>
                        <a href="#">Why buy with Response Real</a>
                    </li>
                    <li>
                        <a href="#">Estate Brokers</a>
                    </li>
                    <li>
                        <a href="#">The Acquisition Process</a>
                    </li>
                    <li>
                        <a href="#">Business Immigration</a>
                    </li>
                    <li>
                        <a href="#">FAQs</a>
                    </li>
                </ul>
            </div>

            <div class="col-lg-4 col-12">
                <ul>
                    <li>
                        <h3>Register as a Seller</h3>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Abu Dhabi</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Dubai</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Sharjah</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Umm Al-Quwain</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Fujairah</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Ras Al Khaimah</a>
                    </li>
                    <li>
                        <a href="#">Sell A Business In Confidentially</a>
                    </li>

                </ul>
            </div>
        </div>
        <div class="row mt-3">
            <div class="col-12 text-center">
                <strong>Response Real Estate Broker 2022©</strong>

            </div>
        </div>
        <div class="p-3"></div>

    </div>

</footer>
