<section class="small-banner d-flex align-items-center"
    style="background-image: url({{ assets($banner['path'] ?? 'images/small-banner.jpg') }})">
    <div class="container ">
        <div class="row">
            <div class="col-12">
                <span class="h1 line ms-font">{!! $banner['heading'] ?? 'Banner heading' !!}</span> <br>
                <span class="sub-heading">{!! $banner['sub-heading'] ?? 'Banner sub-heading' !!}</span>
            </div>
        </div>
    </div>
</section>
