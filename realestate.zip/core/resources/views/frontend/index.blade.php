@extends('layouts.landing')

@section('content')
    <header class="masthead" style="background-image: url({{ assets('images/banner.jpg') }});">
        <div class="container h-100">
            <div class="row h-100 align-items-center justify-content-center">
                <div class="col-lg-6 text-center text-white ">
                    <h1 class="fw-light text-glow">We are the 1st and The <br> Best Business Agent in UAE</h1>
                    <div class="lead">
                        <form action="">
                            <div class="row">
                                <div class="col-11 banner-search">
                                    <input class="form-control" type="text" name="" id="" placeholder="Try Dubai Business">
                                </div>
                                <div class="col-1 d-flex align-items-center justify-content-center bg-black">
                                    <i class="fa fa-search"></i>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </header>

    <!-- Page Content -->
    <section class="about mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-4 ms-font about-left-h">
                            <h2>Response</h2>
                            <span class="text-red text-bold">REAL ESTATE BROKER</span>
                        </div>
                        <span class="vertical-line"></span>
                        <div class="col-7 h1 line">
                            <span>SELLING A BUSINESS</span>
                        </div>
                    </div>
                    <div class="row ms-font">
                        <div class="col-12">
                            <p>
                                If you want to sell a business in <strong>Abu Dhabi, Dubai, Sharjah, Ajman, Umm
                                    Al-Quwain, Fujairah, or Ras Al Khaimah,</strong> you need experienced business sales
                                agents to represent you and guide you through the processes involved in preparing a
                                business for sale and ultimately <strong>selling your business.</strong>
                            </p>
                            <p>
                                <strong>Response Real Estate Brokers is UAE's industry-leading team</strong> of business
                                brokers and experts in business sales when selling a business. Our highly professional
                                and experienced business brokers will walk you through every step of the process, from
                                preparing detailed business summaries to advertising, negotiating, and explaining legal
                                paperwork.
                            </p>
                            <p>
                                Response Real Estate Brokers specializes in business sales ranging from AED 1 million to
                                AED 5 million and above. Our expert business sales agents have represented corporations
                                and individuals in over and above AED 5 million acquisitions, divestments, and mergers.
                                Furthermore, We have collaborated with hundreds of domestic and global businesses,
                                connecting many overseas investors with lucrative local opportunities
                            </p>
                        </div>
                        <div class="col-12 text-right">
                            <button class="btn btn-red">Read more</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-4">
                    <img src="{{ assets('images/about.jpg') }}" alt="">
                    <div class="frame"></div>
                </div>
            </div>
        </div>
    </section>


    <section class="why-us mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-4">
                    <img src="{{ assets('images/whyus.jpg') }}" alt="">
                </div>
                <div class="col-md-8">
                    <div class="row">
                        <div class="col-12 h1 line">
                            <span>Why Response Real Estate Brokers?</span>
                        </div>
                    </div>
                    <div class="row ms-font">
                        <div class="col-12">
                            <p>
                                When you choose Response Real Estate Brokers, you are selecting a well-connected and
                                well-respected team. We communicate clearly, negotiate expertly, and always represent
                                you with integrity and professionalism.
                            </p>
                            <strong>Welcome to our World.</strong>
                            <p>
                                We take the time to fully understand your position, objectives, and options, and because
                                the world of acquisitions and divestitures is complex, we always communicate clearly and
                                without jargon. So, if you're looking to sell or buy a business in UAE, we'll help you
                                achieve your objectives with favorable contract terms.
                            </p>



                        </div>
                    </div>
                </div>

            </div>

        </div>
    </section>

    <section class="our-services mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="row justify-content-center">
                        <div class="col-lg-4 col-6  text-center">
                            <span class="h1 line">Our Services</span>
                        </div>
                        <div class="col-12 text-center ms-font mt-3">
                            <strong>In Response, We Mean Business</strong>
                        </div>
                    </div>
                </div>
            </div>


        </div>
        <div class="container-fluid">
            <div class="row ms-font detail-card">
                <div class="col-1">
                    <div class="swiper-button-prev text-red"></div>
                </div>
                <div class="col-10">
                    <div class="swiper services-swiper">
                        <div class="swiper-wrapper">
                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Businesses Acquisition</h2>
                                                <p class="card__snippet">
                                                    Response Real Estate Brokers can assist you all year round. Whether you
                                                    already have a business in mind or are starting from scratch.
                                                    You will benefit from our solid industry knowledge and extensive network
                                                    as we specialize in transactions starting at 1 million AED. We find
                                                    businesses that meet your needs, even if they are not formally 'on the
                                                    market.
                                                    Response Real estate Brokers can handle the entire acquisition process
                                                    for you, from search and selection to negotiation, landlord
                                                    documentation, and settlement. As an added bonus, we can prepare your
                                                    business plan.
                                                </p>
                                                <a href="{{ route('frontend.our.services') }}" class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Selling a Business</h2>
                                                <p class="card__snippet">
                                                    If you want to sell your company with confidence, Response Real Estate
                                                    Brokers is the right choice. We work entirely on your behalf to secure
                                                    the best possible price and contract terms for you.

                                                    Response Real Estate Brokers can prepare your information memorandum and
                                                    business plan, as well as present it to our extensive network of high
                                                    net worth individuals and investors. We have connections with
                                                    individuals looking for offshore investments or business acquisitions.

                                                </p>
                                                <a href="{{ route('frontend.our.services') }}" class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Off Market Projects</h2>
                                                <p class="card__snippet">
                                                    For confidentiality and other reasons, our clients frequently prefer
                                                    that their projects not be advertised or listed for sale At the moment,
                                                    Response Real Estate Brokers is handling many off-market projects.

                                                    Projects typically range from AED 1 million to AED 5+ million in value.
                                                    Please contact us as soon as possible; our dedicated team will be happy
                                                    to discuss your strategic acquisition or divestment with you.
                                                </p>
                                                <a href="{{ route('frontend.our.services') }}" class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>



                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Capital Raising</h2>
                                                <p class="card__snippet">
                                                    Are you looking to grow your business, pay off debt, start a new
                                                    venture, or capitalize on a lucrative market opportunity?

                                                    With access to a global equity network, Response Real Estate brokers can
                                                    assist you in raising the funds you require to meet your objectives. We
                                                    raise capital for various businesses in all industries, providing
                                                    invaluable expertise at every stage of the transaction.

                                                </p>
                                                <a href="{{ route('frontend.our.services') }}" class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>


                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Business Valuations</h2>
                                                <p class="card__snippet">
                                                    Our team members are Registered Business Valuers, which means we are
                                                    qualified to perform a formal valuation of your existing or prospective
                                                    business.

                                                    We apply a robust methodology to every business we value and have access
                                                    to an up-to-date database of businesses sold by industry and location.
                                                    We also perform various types of valuations to meet your needs and
                                                    budget, such as:

                                                </p>
                                                <a href="{{ route('frontend.our.services') }}" class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>


                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Business Valuations</h2>
                                                <p class="card__snippet">
                                                    Our team members are Registered Business Valuers, which means we are
                                                    qualified to perform a formal valuation of your existing or prospective
                                                    business.

                                                    We apply a robust methodology to every business we value and have access
                                                    to an up-to-date database of businesses sold by industry and location.
                                                    We also perform various types of valuations to meet your needs and
                                                    budget, such as:

                                                </p>
                                                <a href="{{ route('frontend.our.services') }}"
                                                    class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Business Consultation</h2>
                                                <p class="card__snippet">
                                                    Response Real Estate Brokers' key members are accredited and experienced
                                                    property consultants. This indicates we're in an excellent position to
                                                    help you with
                                                </p>
                                                <a href="{{ route('frontend.our.services') }}"
                                                    class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>


                            <div class="swiper-slide">
                                <div class="col-lg-4 col-md-6 col-12">
                                    <div class="card">
                                        <figure class="card__thumb">
                                            <img src="https://source.unsplash.com/75S9fpDJVdo/300x510"
                                                alt="Picture by Kyle Cottrell" class="card__image">
                                            <figcaption class="card__caption">
                                                <h2 class="card__title">Business Immigration</h2>
                                                <p class="card__snippet">
                                                    Do you want to buy a business and move to the UAE If this is the case,
                                                    Response Real Estate Brokers will help you find business prospects,
                                                    manage the transaction, write your company strategy, and assist you with
                                                    your visa application. Some of our experts are fluent in a foreign
                                                    language and focus solely on business immigration transactions.
                                                </p>
                                                <a href="{{ route('frontend.our.services') }}"
                                                    class="card__button">Read
                                                    more
                                                </a>
                                            </figcaption>
                                        </figure>
                                    </div>
                                </div>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-1">
                    <div class="swiper-button-next text-red"></div>
                </div>

            </div>
        </div>

        <div class="black-ribbon">
            <div id="services-swiper-pagination" class="swiper-pagination"></div>
        </div>

    </section>

    <section class="listing">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="row justify-content-center">
                        <div class="col-4  text-center">
                            <span class="h1 line">Business for sale</span>
                        </div>
                        <div class="col-12 text-center ms-font mt-3">
                            <strong>From AED 1- 5 Million and 5 Million and Up</strong>
                        </div>
                    </div>
                </div>
            </div>

            <div class="row ms-font mt-4">
                <div class="col-lg-4 col-12 listing-card mt-5">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 listing-card mt-5">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 listing-card mt-5">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>

    <section class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 ">
                    <span class="bg-black-left"></span>
                    <div class="row mt-3">
                        <div class="col-12">
                            <div class="swiper video-swiper" style="height: 80%">
                                <div class="swiper-wrapper">
                                    <div class="swiper-slide">
                                        <div class="col-12">
                                            <div class="youtube"
                                                data-embed="{{ Helper::getYoutubeIdFromUrl(URL::to('https://www.youtube.com/watch?v=m80E1K75vDI&ab_channel=QuietQuest-StudyMusic')) }}">
                                                <div class="play-button"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="col-12">
                                            <div class="youtube"
                                                data-embed="{{ Helper::getYoutubeIdFromUrl(URL::to('https://www.youtube.com/watch?v=m80E1K75vDI&ab_channel=QuietQuest-StudyMusic')) }}">
                                                <div class="play-button"></div>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="swiper-slide">
                                        <div class="col-12">
                                            <div class="youtube"
                                                data-embed="{{ Helper::getYoutubeIdFromUrl(URL::to('https://www.youtube.com/watch?v=m80E1K75vDI&ab_channel=QuietQuest-StudyMusic')) }}">
                                                <div class="play-button"></div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>


                    </div>
                    <div class="row hiw-pagination">
                        <div class="col-6">
                            <h2>How it works</h2>
                        </div>
                        <div class="col-6">
                            <div id="video-swiper-pagination" class="swiper-pagination"></div>
                        </div>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="row w-100">
                        <div class="col-12">
                            <span class="h1 line">Register with us</span>
                            <p>
                                If you want to buy or sell a Business in UAE, Response Real Estate Broker is just a
                                click away. Register now, so that we can help you with your Business
                            </p>
                        </div>
                    </div>

                    <div class="row registration w-100">
                        <div class="col-6">
                            <a href="{{ route('buyer.register') }}">
                                <img src="{{ assets('images/reg1.jpg') }}" alt="">
                                <span>Buyer <br> Registration</span>
                            </a>
                        </div>
                        <div class="col-6">
                            <a href="{{ route('seller.register') }}" >
                                <img src="{{ assets('images/reg2.jpg') }}" alt="">
                                <span>Seller <br> Registration</span>
                            </a>
                        </div>
                    </div>

                </div>

            </div>
        </div>

    </section>


    <section class="mt-5">
        <div class="container">
            <div class="row">
                <div class="col-md-6 blog-home">
                    <div class="row">
                        <div class="col-12 h1 line">
                            <span>Fresh from the blog</span>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-3">
                            <img src="{{ assets('images/reg1.jpg') }}" alt="">
                        </div>
                        <div class="col-9 blog-details">
                            <h4>Looking for Business</h4>
                            <span>Lorem ipsum Lorem</span> <br>
                            <span>Date: {{ date('d M, Y') }}</span>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-3">
                            <img src="{{ assets('images/reg1.jpg') }}" alt="">
                        </div>
                        <div class="col-9 blog-details">
                            <h4>Looking for Business</h4>
                            <span>Lorem ipsum Lorem</span> <br>
                            <span>Date: {{ date('d M, Y') }}</span>
                        </div>
                    </div>

                    <div class="row mb-2">
                        <div class="col-3">
                            <img src="{{ assets('images/reg1.jpg') }}" alt="">
                        </div>
                        <div class="col-9 blog-details">
                            <h4>Looking for Business</h4>
                            <span>Lorem ipsum Lorem</span> <br>
                            <span>Date: {{ date('d M, Y') }}</span>
                        </div>
                    </div>

                </div>

                <div class="col-md-6">
                    <div class="row">
                        <div class="col-12 h1 line">
                            <span>Need Help? Get in touch with us</span>
                        </div>
                    </div>
                    <div class="row touch-with-us">
                        <div class="col-6 b-r">
                            <img src="{{ assets('images/whatsapp-icon.png') }}" alt="">
                            <p>whatsapp</p>
                        </div>

                        <div class="col-6">
                            <a href="mailto:info@amlakauction.ae">
                                <img src="{{ assets('images/email-icon.png') }}" alt="">
                                <p>email</p>
                            </a>
                        </div>

                        <div class="col-6 b-t b-r">
                            <img src="{{ assets('images/call-icon.png') }}" alt="">
                            <p>call back</p>
                        </div>

                        <div class="col-6 b-t">
                            <img src="{{ assets('images/video-icon.png') }}" alt="">
                            <p>video call</p>
                        </div>
                    </div>
                </div>
            </div>


        </div>

    </section>


    <section class="mt-5 partners">
        <div class="row">
            <div class="col-lg-3 col-12 our-partners">
                <div class="col-12 text-center">
                    <span class="h1 line">Our partners</span>
                </div>
            </div>
            <div class="col-lg-9 col-12">
                <div class="swiper partners-swiper">
                    <div class="swiper-wrapper">
                        <div class="swiper-slide">
                            <img src="{{ assets('images/amlak-logo.webp') }}">
                        </div>
                        <div class="swiper-slide">
                            <img src="{{ assets('images/response-logo.png') }}">
                        </div>
                        <div class="swiper-slide">
                            <img src="{{ assets('images/valuation-logo.jpg') }}">
                        </div>
                    </div>
                    <div id="partner-next" class="swiper-button-next text-red"></div>
                    <div id="partner-prev" class="swiper-button-prev text-red"></div>
                    <div class="swiper-pagination"></div>
                </div>
            </div>
        </div>
    </section>
@endsection

@section('js')
    <script>
        var swiper = new Swiper(".services-swiper", {
            slidesPerView: 3,
            spaceBetween: 30,
            slidesPerGroup: 3,
            loop: true,
            loopFillGroupWithBlank: true,
            pagination: {
                el: "#services-swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: ".swiper-button-next",
                prevEl: ".swiper-button-prev",
            },
        });

        var partnersSwiper = new Swiper(".partners-swiper", {
            slidesPerView: 3,
            spaceBetween: 30,
            slidesPerGroup: 3,
            loop: true,
            loopFillGroupWithBlank: true,
            pagination: {
                el: ".swiper-pagination",
                clickable: true,
            },
            navigation: {
                nextEl: "#partner-next",
                prevEl: "#partner-prev",
            },
        });

        var videoSwiper = new Swiper(".video-swiper", {
            pagination: {
                el: "#video-swiper-pagination",
                clickable: true
            },
        });
    </script>
@endsection
