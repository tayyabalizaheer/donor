@extends('layouts.frontend')

@section('content')
    <section class="custom-page contact-us mt-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="line">Ready to find your business broker?</h2>
                            <p>
                                Got a question? Need a little help with your business
                                Then you're in the right place. Just fill out the form
                                given below and one of our representatives will get back to
                            </p>
                        </div>
                    </div>

                    <div class="row touch-with-us">
                        <div class="col-6">
                            <div class="box-shadow">
                                <img src="{{ assets('images/whatsapp-icon.png') }}" alt="">
                                <p>whatsapp</p>
                            </div>

                        </div>

                        <div class="col-6">
                            <div class="box-shadow">
                                <a href="mailto:info@amlakauction.ae">
                                    <img src="{{ assets('images/email-icon.png') }}" alt="">
                                    <p>email</p>
                                </a>
                            </div>

                        </div>

                        <div class="col-6">
                            <div class="box-shadow">
                                <img src="{{ assets('images/call-icon.png') }}" alt="">
                                <p>call back</p>
                            </div>

                        </div>

                        <div class="col-6">
                            <div class="box-shadow">
                                <img src="{{ assets('images/video-icon.png') }}" alt="">
                                <p>video call</p>
                            </div>

                        </div>
                    </div>
                </div>

                <div class="col-lg-6 cv-form col-12 ">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="line">Get intouch with us</h2>
                            <form action="{{ route('frontend.contactus') }}" method="post">
                                @csrf
                                <div class="form-group">
                                    <label class="form-label" for="">Name</label>
                                    <input type="text" name="name" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="">Email</label>
                                    <input type="text" name="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="">Phone No.</label>
                                    <input type="text" name="phone" class="form-control">
                                </div>

                                <div class="form-group">
                                    <label class="form-label" for="">Message</label>
                                    <textarea name="phone" class="form-control"></textarea>
                                </div>

                                <div class="form-group text-center">
                                    <button class="btn btn-black btn-block">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>



                </div>
            </div>


        </div>
        <div class="col-12 np mt-5">
            <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3613.08869170684!2d55.175124014959735!3d25.09885888394203!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3e5f6b776f2b55d3%3A0x1c76655c23b0b5fe!2sGrosvenor%20Business%20Tower!5e0!3m2!1sen!2sae!4v1648899753655!5m2!1sen!2sae"
                width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy"
                referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
    </section>
@endsection
