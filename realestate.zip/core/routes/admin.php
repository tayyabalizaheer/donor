<?php

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;

Route::group(['prefix' => 'admin', 'as' => 'admin.'], function () {

    Route::get('/login', [LoginController::class, 'adminLogin'])->name('login');
    Route::post('/login', [LoginController::class, 'adminLoginPost']);

    Route::group(['middleware'=>'admin'], function () {
        Route::get('/', [AdminController::class, 'index'])->name('dashboard.index');
        Route::get('/dashboard', [AdminController::class, 'index'])->name('dashboard');
        Route::get('/users/{role?}', [UserController::class, 'index'])->name('users')->where('role', 'admin|buyer|seller');
        Route::get('/users/create', [UserController::class, 'create'])->name('users.create');
        Route::post('/users/store', [UserController::class, 'store'])->name('users.store');
    });



});
