<?php

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Auth\LoginController;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Mail;
use Illuminate\Http\Request;
use App\Http\Controllers\Auth\RegisterController;
use App\Http\Controllers\Frontend\ListingController;
use App\Http\Controllers\HomeController;
use Illuminate\Support\Facades\Auth;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/
Route::get('/logout', [LoginController::class, 'logout'])->name('logout');

Route::group(['prefix' => 'buyer', 'as' => 'buyer.'], function () {
    Route::get('/register', [RegisterController::class, 'buyerRegister'])->name('register');
    Route::post('/register', [RegisterController::class, 'buyerRegisterStore'])->name('register.store');
});

Route::group(['prefix' => 'seller', 'as' => 'seller.'], function () {
    Route::get('/register', [RegisterController::class, 'sellerRegister'])->name('register');
    Route::post('/register', [RegisterController::class, 'sellerRegisterStore'])->name('register.store');
});

Route::get('welcome',function(){
    return view('email.welcome');
});

Route::group(['as' => 'frontend.'], function () {

    Route::get('/', [HomeController::class, 'index'])->name('index');
    Route::get('/our-services', [HomeController::class, 'our_services'])->name('our.services');
    Route::get('/contact-us', [HomeController::class, 'contact_us'])->name('contact.us');
    Route::get('/about-us', [HomeController::class, 'about_us'])->name('about.us');
    Route::get('/career', [HomeController::class, 'career'])->name('career');
    Route::get('/listing', [ListingController::class, 'index'])->name('listing.index');
    Route::get('/listing/{id}', [ListingController::class, 'show'])->name('listing.show');

    Route::post('contact-us', function (Request $request) {
        try {
            $data = $request->except('_token');
            $data['adminEmail'] = 'amlakauctionae@gmail.com';
            Mail::send('emails.contactus', $data, function ($msg) use ($data) {
                $msg->from('no-reply@amlakauction.ae');
                $msg->to($data['adminEmail'], $data['name'])->subject('Contact Us');
            });
        } catch (\Throwable $th) {
        }

        return back()->with('success', 'Message delivered!');
    })->name('contactus');
});



Auth::routes();
