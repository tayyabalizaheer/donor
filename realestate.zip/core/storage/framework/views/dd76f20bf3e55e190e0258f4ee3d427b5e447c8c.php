<?php $__env->startSection('content'); ?>
    <section class="custom-page career-page mt-5 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-12">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="line">Sell great Businesses with Us</h2>
                            <p>
                                We’re always open to new and fresh talent, so check
                                out our open positions.
                                <br>
                                When you join Response Real Estate Brokers, You join the
                                best corporate office in Dubai. We ensure our employees
                                have a work-life balance to boost their innovation and
                                productivity
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h2 class="line">Working at Response Real Estate Brokers</h2>
                            <p>
                                At Response Real Estate Brokers, we're on a mission to make
                                the process of selling and buying businesses easier and
                                ensure their survival and prosperity. We collaborate with
                                some of the world's most recognizable businesses to help
                                them transit their buying and selling safely, and the bottom
                                line ‘Through cost savings and revenue growth’ Be a part of us.
                                Send your CV today!
                            </p>
                        </div>
                    </div>
                </div>

                <div class="col-lg-6 cv-form col-12 ">
                    <div class="row">
                        <div class="col-12">
                            <h2 class="line">Submit your cv</h2>
                            <span>We need individuals who offer unique talents
                                and behaviors to help us construct and grow</span>
                            <form action="">
                                <div class="form-group">
                                    <label class="form-label" for="">Name</label>
                                    <input type="text" name="name" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="">Email</label>
                                    <input type="text" name="email" class="form-control">
                                </div>
                                <div class="form-group">
                                    <label class="form-label" for="">Phone No.</label>
                                    <input type="text" name="phone" class="form-control">
                                </div>
                                <div class="d-flex">
                                    <div class="col-6 np pr-2">
                                        <div class="form-group">
                                            <label class="form-label" for="">Position</label>
                                            <input type="text" name="position" class="form-control">
                                        </div>
                                    </div>

                                    <div class="col-6 np pl-2">
                                        <div class="form-group">
                                            <label class="form-label" for="">Attach CV</label>
                                            <input type="text" name="phone" class="form-control btn btn-black"
                                                value="UPLOAD">
                                        </div>
                                    </div>
                                </div>

                                <div class="form-group text-center">
                                    <button class="btn btn-black col-4">Submit</button>
                                </div>
                            </form>
                        </div>
                    </div>



                </div>
            </div>

        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/pages/career.blade.php ENDPATH**/ ?>