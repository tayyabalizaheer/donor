<div class="video-overlay"><i class="fa fa-times close" aria-hidden="true"></i>
    <div class="container">
    <div class="row justify-conten-center align-items-center vh-100">
        <div class="col-sm-12">
        <iframe id="youtube-popup-iframe" class="iframe-popup" alt="works" src="" style="width:100%;height:500px;"></iframe>
        </div>
    </div>
    </div>
</div>
<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/includes/youtube.blade.php ENDPATH**/ ?>