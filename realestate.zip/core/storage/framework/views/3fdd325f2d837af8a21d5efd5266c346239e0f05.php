<h4 class="fw-bold py-3 mb-4">
    <a class="text-muted fw-light" href="<?php echo e(route('admin.dashboard')); ?>">Home /</a>
    <?php $__currentLoopData = $paths; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $path): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a class="text-muted <?php echo e($loop->last ? 'active' : 'fw-light'); ?>  " href="<?php echo e(url($path)); ?>"><?php echo e(str_replace('-', ' ', $path)); ?> <?php echo e(($loop->last) ? '':'/'); ?></a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</h4>

<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/components/breadcrumb.blade.php ENDPATH**/ ?>