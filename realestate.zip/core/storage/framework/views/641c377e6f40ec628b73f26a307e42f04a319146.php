<?php $__env->startSection('content'); ?>
    <section class="custom-page about-us mt-5" style="background-image: url(<?php echo e(assets('images/about-us.png')); ?>)">
        <div class="container">
            <div class="row">
                <div class="col-lg-4 col-12 about-left">
                    <h1 class="line"> <span class="text-red">Why</span> we are the <span
                            class="text-red">best</span>?
                    </h1>
                </div>
                <div class="col-lg-8 col-12 about-right">

                    <div class="row">
                        <div class="col-12">
                            <p>
                                <span class="text-red">Response Real Estate Brokers</span> is a one-stop for keen
                                business owners in the United Arab
                                looking to connect with investors. Response Real Estate has collaborated with hundreds of
                                businesses – and has connected many people in UAE with lucrative local opportunities
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h1 class="line">Welcome to Our World</h1>
                            <p>
                                When working with Response Real Estate, we help you to move in a better hassle-free world –
                                in every possible way.
                                We take time to fully understand your situation, goals, and options when it comes to buying
                                or selling a business. We assist you in experiencing a much simpler and more convenient
                                method of buying and selling a business.
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h1 class="line">We excel as Business Brokers</h1>
                            <p>
                                <strong>We are here for you</strong> <br>
                                Our technical knowledge is unrivaled, we are also well-known in the industry for being
                                skilled business brokers. We understand what it takes to achieve the best results for our
                                clients. Throughout the negotiation process, we remain calm and confident – never
                                jeopardizing your strategic position or integrity.


                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h1 class="line">A powerful Network, You Can Rely Upon</h1>
                            <p>
                                Whether you want to sell or buy, you'll benefit from our extensive network. If you want to
                                sell your company, we can put it in front of the right people at the right time. If you're
                                looking to buy, we're aware of opportunities that aren't on the open market.
                            </p>
                        </div>
                    </div>

                    <div class="row">
                        <div class="col-12">
                            <h1 class="line">We help your Businesses to (re)define Success</h1>
                            <p>
                                When you rely on Response Real Estate, you rely on a team that is honest, ethical, and
                                upfront. We understand that any advice we give has a direct impact on your success and
                                integrity. And we value your privacy and confidentiality

                                We also go to great lengths to ensure that your opportunity is solid and that your business
                                case is solid. After all, we can only succeed if you succeed
                                Contact Response Real Estate today if you want to buy or sell a business. We act entirely on
                                your behalf and are by your side at all times.

                            </p>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/pages/about_us.blade.php ENDPATH**/ ?>