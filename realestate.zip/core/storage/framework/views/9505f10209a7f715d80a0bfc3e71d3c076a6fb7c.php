<table>
    <tr>
        <th>Name:</th>
        <td><?php echo e($name); ?></td>
    </tr>

    <tr>
        <th>Email:</th>
        <td><?php echo e($email); ?></td>
    </tr>

    <tr>
        <th>Phone:</th>
        <td><?php echo e($phone); ?></td>
    </tr>

    <tr>
        <th>Message:</th>
        <td><?php echo e($messagetext); ?></td>
    </tr>

</table>
<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/emails/contactus.blade.php ENDPATH**/ ?>