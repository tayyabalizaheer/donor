<?php $__env->startSection('content'); ?>
<div class="card mb-4">
    <div class="card-header d-flex justify-content-between align-items-center">
        <h5 class="mb-0">Add new User</h5>
        <small class="text-muted float-end">Default label</small>
    </div>
    <div class="card-body">
        <form action="<?php echo e(route('admin.users.store')); ?>" method="POST">
            <?php echo $__env->make('admin.users.fields', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/admin/users/create.blade.php ENDPATH**/ ?>