<?php $__env->startSection('content'); ?>
    <section class="custom-page mt-5 mb-5">
        <div class="container">
            <div class="row">
                <div class="col-12">
                    <h4 class="line">Businesses Acquisition</h4>
                    <p>
                        Response Real Estate Brokers can assist you all year round. Whether you
                        already have a business in mind or are starting from scratch.
                        You will benefit from our solid industry knowledge and extensive network
                        as we specialize in transactions starting at 1 million AED. We find
                        businesses that meet your needs, even if they are not formally 'on the
                        market.
                        Response Real estate Brokers can handle the entire acquisition process
                        for you, from search and selection to negotiation, landlord
                        documentation, and settlement. As an added bonus, we can prepare your
                        business plan.
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="line">Selling a Business</h4>
                    <p>
                        If you want to sell your company with confidence, Response Real Estate Brokers is the right
                        choice.
                        We work entirely on your behalf to secure the best possible price and contract terms for you.

                        Response Real Estate Brokers can prepare your information memorandum and business plan, as well
                        as
                        present it to our extensive network of high net worth individuals and investors. We have
                        connections
                        with individuals looking for offshore investments or business acquisitions.
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="line">Off Market Projects</h4>
                    <p>
                        For confidentiality and other reasons, our clients frequently prefer that their projects not
                        be
                        advertised or listed for sale At the moment, Response Real Estate Brokers is handling many
                        off-market projects.

                        Projects typically range from AED 1 million to AED 5+ million in value.
                        Please contact us as soon as possible; our dedicated team will be happy to discuss your
                        strategic
                        acquisition or divestment with you.


                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="line">Capital Raising</h4>
                    <p>
                        Are you looking to grow your business, pay off debt, start a new venture, or capitalize on a
                        lucrative market opportunity?

                        With access to a global equity network, Response Real Estate brokers can assist you in raising the
                        funds you require to meet your objectives. We raise capital for various businesses in all
                        industries, providing invaluable expertise at every stage of the transaction.
                    </p>
                </div>
            </div>


            <div class="row">
                <div class="col-12">
                    <h4 class="line">Business Valuations</h4>
                    <p>
                        Our team members are Registered Business Valuers, which means we are qualified to perform a formal
                        valuation of your existing or prospective business.

                        We apply a robust methodology to every business we value and have access to an up-to-date database
                        of businesses sold by industry and location. We also perform various types of valuations to meet
                        your needs and budget, such as:
                    <ul>
                        <li>
                            <p>Complete business valuations </p>
                        </li>
                        <li>
                            <p>Market appraisals </p>
                        </li>
                        <li>
                            <p>Limited Valuations </p>
                        </li>
                    </ul>
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="line">Business Consultation</h4>
                    <p>
                        Response Real Estate Brokers' key members are accredited and experienced property consultants. This
                        indicates we're in an excellent position to help you with:
                    <ul>
                        <li>
                            <p> Joint ventures in business and Property Business purchases: We provide a full-service
                                property
                                business buyer's agency, from sourcing and approaching to negotiating and settling.</p>
                        </li>

                        <li>
                            <p> Auction bidding: We can help you boost your chances of success on your big day.
                                Can we help you with your next project?</p>
                        </li>
                    </ul>
                    </p>
                </div>
            </div>

            <div class="row">
                <div class="col-12">
                    <h4 class="line">Business Immigration</h4>
                    <p>
                        Do you want to buy a business and move to the UAE If this is the case, Response Real Estate Brokers
                        will help you find business prospects, manage the transaction, write your company strategy, and
                        assist you with your visa application. Some of our experts are fluent in a foreign language and
                        focus solely on business immigration transactions.
                    </p>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/pages/our_services.blade.php ENDPATH**/ ?>