<?php if($message = Session::get('success')): ?>
<div class="alert alert-success alert-dismissible" role="alert">
    <strong><?php echo e($message); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
<div class="alert alert-danger alert-dismissible" role="alert">
    <strong><?php echo e($message); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<?php if($message = Session::get('warning')): ?>
<div class="alert alert-warning alert-dismissible" role="alert">
    <strong><?php echo e($message); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($message = Session::get('primary')): ?>
<div class="alert alert-primary alert-dismissible" role="alert">
    <strong><?php echo e($message); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>

<?php if($message = Session::get('info')): ?>
<div class="alert alert-info alert-dismissible" role="alert">
    <strong><?php echo e($message); ?></strong>
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>


<?php if($errors->any()): ?>
<div class="alert alert-warning alert-dismissible" role="alert">
    Please check the form below for errors
    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
</div>
<?php endif; ?>








<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/admin/includes/flash-message.blade.php ENDPATH**/ ?>