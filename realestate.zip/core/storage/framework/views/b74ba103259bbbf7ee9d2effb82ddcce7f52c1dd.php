<?php $__env->startSection('content'); ?>
    <section class="listing-page mt-5">
        <div class="container">
            <div class="row listing-search-header">
                <div class="col-12">
                    <h1 class="line ms-font">Current <span class="text-red">Listing</span> </h1>
                    <div class="row">
                        <div class="col-12 col-md-3">
                            <div class="form-group">
                                <label for="">Search for</label>
                                <input type="text" name="q" id="q" class="form-control" placeholder="">
                            </div>
                        </div>

                        <div class="col-12 col-md-3">
                            <div class="form-group">
                                <label for="">Business Categories</label>
                                <select type="text" name="category" id="q" class="form-control" placeholder="">
                                    <option value="Accommodation/Tourism">Accommodation/Tourism</option>
                                    <option value="Automotive">Automotive</option>
                                    <option value="Beauty/Health">Beauty/Health</option>
                                    <option value="Education/Training">Education/Training</option>
                                    <option value="Food/Hospitality">Food/Hospitality</option>
                                    <option value="Franchise">Franchise</option>
                                    <option value="Home/Garden">Home/Garden</option>
                                    <option value="Import/Export/Whole">Import/Export/Whole</option>
                                    <option value="Industrial/Manufacturing">Industrial/Manufacturing</option>
                                    <option value="Leisure/Entertainment">Leisure/Entertainment</option>
                                    <option value="Professional">Professional</option>
                                    <option value="Retail">Retail</option>
                                    <option value="Rural">Rural</option>
                                    <option value="Services">Services</option>
                                    <option value="Transport/Distribution">Transport/Distribution</option>

                                </select>
                            </div>
                        </div>

                        <div class="col-12 col-md-3">
                            <div class="form-group">
                                <label for="">Location</label>
                                <select type="text" name="location" id="q" class="form-control" placeholder="">
                                    <option value="Dubai">Dubai</option>
                                    <option value="Abu Dhabi">Abu Dhabi</option>
                                    <option value="Sharjah">Sharjah</option>
                                    <option value="Ajman">Ajman</option>
                                    <option value="Umm Al-Quwain">Umm Al-Quwain</option>
                                    <option value="Fujairah">Fujairah</option>
                                    <option value="Ras Al Khaimah">Ras Al Khaimah</option>
                                </select>
                            </div>
                        </div>

                        <div class="col-12 col-md-2">
                            <div class="form-group">
                                <label for="">Price Range</label>
                                <select type="text" name="category" id="q" class="form-control" placeholder="">
                                    <option value="500000-1000000">500k - 1M</option>
                                    <option value="1000000-5000000">1M - 5M</option>
                                    <option value="5000000">5M & Above</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-12 col-md-1 btn-search">
                            <div class="form-group">
                                <label for=""> &nbsp; </label>
                                <button
                                    class="d-flex align-items-center justify-content-center bg-black text-white btn btn-block"><i
                                        class="fa fa-search"></i></button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>



        </div>
    </section>

    <section class="listing mb-5">
        <div class="container">
            <div class="row ms-font listing-card mt-4">
                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>


                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-red">Sale</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-black">Under Loi</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>

                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="col-lg-4 col-12 mt-5 listing-card">
                    <span class="status-before"></span>
                    <span class="status bg-grey">sold</span>
                    <div class="grid__item">
                        <div class="card">
                            <img class="card__img"
                                src="https://images.unsplash.com/photo-1485160497022-3e09382fb310?ixlib=rb-1.2.1&amp;ixid=eyJhcHBfaWQiOjEyMDd9&amp;auto=format&amp;fit=crop&amp;w=2250&amp;q=80"
                                alt="Desert">
                            <span class="price">Price: 2,000,000 AED</span>
                            <div class="card__content">
                                <div class="card__header">
                                    <h1>Coffee Shop with authentic interior at Jumeirah, Dubai </h1>
                                    <span>Location: Jumeriah, Dubai</span> <br>
                                    <span>Ref ID: 001</span>
                                </div>
                                <div class="card__btn">
                                    <a>View More</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/listing/index.blade.php ENDPATH**/ ?>