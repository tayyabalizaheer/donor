<section class="small-banner d-flex align-items-center"
    style="background-image: url(<?php echo e(assets($banner['path'] ?? 'images/small-banner.jpg')); ?>)">
    <div class="container ">
        <div class="row">
            <div class="col-12">
                <span class="h1 line ms-font"><?php echo $banner['heading'] ?? 'Banner heading'; ?></span> <br>
                <span class="sub-heading"><?php echo $banner['sub-heading'] ?? 'Banner sub-heading'; ?></span>
            </div>
        </div>
    </div>
</section>
<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/includes/banner.blade.php ENDPATH**/ ?>