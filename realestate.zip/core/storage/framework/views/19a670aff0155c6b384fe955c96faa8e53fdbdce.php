<footer class="content-footer footer bg-footer-theme">
    <div class="container-xxl d-flex flex-wrap justify-content-between py-2 flex-md-row flex-column">
        <div class="mb-2 mb-md-0">
            ©
            <script>
                document.write(new Date().getFullYear());
            </script>
        </div>
        <div>
            <a href="<?php echo e(route('admin.dashboard')); ?>" class="footer-link me-4">Dashboard</a>
        </div>
    </div>
</footer>
<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/admin/includes/footer.blade.php ENDPATH**/ ?>