<div class="container">
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarTogglerDemo01"
        aria-controls="navbarTogglerDemo01" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
        <img id="black-logo" src="<?php echo e(assets('images/logo.png')); ?>" alt="">
        <img id="white-logo" src="<?php echo e(assets('images/white-logo.png')); ?>" alt="">
    </a>
    <div class="collapse navbar-collapse">
        <div class="ml-auto">
            <ul class="navbar-nav ml-auto mt-2 mt-lg-0">
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('frontend.about.us')); ?>">About Us</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('buyer.register')); ?>">Buy a Business</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('seller.register')); ?>">Sell a Business</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('frontend.listing.index')); ?>">Listing</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#" data-toggle="modal" data-target="#contact-us">Sold</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="#" data-toggle="modal" data-target="#contact-us">off Market</a>
                </li>

                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('frontend.contact.us')); ?>">Contact us</a>
                </li>

            </ul>
            <ul class="navbar-nav float-right">
                <li class="nav-item">
                    <a class="nav-link" href="mailto:info@amlakauction.ae">info@amlakauction.ae</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="tel:+971 44222658">+971 44222658</a>
                </li>

            </ul>
        </div>

    </div>
</div>
<?php /**PATH C:\xampp\htdocs\realestate\core\resources\views/frontend/includes/header.blade.php ENDPATH**/ ?>