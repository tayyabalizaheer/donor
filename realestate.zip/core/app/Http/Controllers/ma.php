<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ma extends Controller
{
    //
}
