<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {
        return view('frontend.index');
    }

    public function our_services()
    {
        $banner['heading'] = "Our Services";
        $banner['sub-heading'] = "In <span class='text-red'>Response</span>, We mean  <span class='text-red'>Business</span>";
        return view('frontend.pages.our_services', compact('banner'));
    }

    public function career()
    {
        $banner['heading'] = "career";
        $banner['sub-heading'] = "Be part of our team";
        return view('frontend.pages.career', compact('banner'));
    }



    public function about_us()
    {
        return view('frontend.pages.about_us');
    }

    public function contact_us()
    {
        return view('frontend.pages.contact_us');
    }
}
