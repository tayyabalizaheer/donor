<?php

namespace App\Http\Controllers\Frontend;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class ListingController extends Controller
{

    public function index(Request $request)
    {
        $banner['heading'] = "Business for sale";
        $banner['sub-heading'] = "Response is here to help you buy a business";
        return view('frontend.listing.index', compact('banner'));
    }

    public function show()
    {

        return view('frontend.listing.detail');
    }
}
